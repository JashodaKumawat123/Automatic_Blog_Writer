module.exports = async function researchAgent(topic) {
  return `Key points about ${topic}:
- Point A
- Point B
- Point C`;
};