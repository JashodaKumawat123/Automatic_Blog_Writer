const express = require('express');
const router = express.Router();

const researchAgent = require('../agents/research');
const outlineAgent  = require('../agents/outline');
const writerAgent   = require('../agents/writer');
const memory        = require('../memory/session');

// POST /api/write  { topic: "Quantum Computing" }
router.post('/write', async (req, res) => {
  const { topic } = req.body;
  if (!topic) return res.status(400).json({ error: 'Missing topic' });

  // 1️⃣ Load previous session memory (MCP long‑term memory)
  const sessionMemory = memory.load();

  // 2️⃣ Multi‑agent pipeline (MCP context routing)
  const research = await researchAgent(topic, sessionMemory);
  const outline  = await outlineAgent (topic, research, sessionMemory);
  const blog     = await writerAgent  (topic, research, outline, sessionMemory);

  // 3️⃣ Persist new context (topic) for future requests
  memory.save(topic);

  res.json({ blog });
});

module.exports = router;
