module.exports = async function writerAgent(topic, research, outline, memory) {
  return `
### ${topic}

${outline}

---

**Details**

${research}

---

*Past topics in this session:* ${memory.pastTopics.join(', ') || 'None'}
  `.trim();
};
