module.exports = async function outlineAgent(topic, research /*, memory */) {
  const lines = research.split('\n').slice(1); // discard "Research Notes:"
  return `Outline for ${topic}:\n1. Introduction\n2. ${lines[0]}\n3. ${lines[1]}\n4. Conclusion`;
};
