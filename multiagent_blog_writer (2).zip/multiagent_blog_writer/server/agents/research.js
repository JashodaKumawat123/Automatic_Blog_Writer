module.exports = async function researchAgent(topic /*, memory */) {
  // Simulated research – replace with real LLM call
  const bullets = [
    `Overview of ${topic}`,
    `Key benefit A`,
    `Current challenge`,
  ];
  return `Research Notes:\n- ${bullets.join('\n- ')}`;
};
