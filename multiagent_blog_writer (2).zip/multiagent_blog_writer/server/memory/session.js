const fs   = require('fs');
const path = require('path');
const file = path.join(__dirname, 'memory.json');

/** Load memory or return an empty structure */
function load() {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return { pastTopics: [] }; }
}

/** Append the latest topic and persist */
function save(topic) {
  const mem = load();
  mem.pastTopics.push(topic);
  fs.writeFileSync(file, JSON.stringify(mem, null, 2));
}

module.exports = { load, save };
